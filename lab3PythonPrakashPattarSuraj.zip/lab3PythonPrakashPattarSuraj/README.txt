The submission contains 3 files:

	- lab3ImpFunction.py: This file contains all the functions useful for this 
	lab. 
		- For using functions from numpy module use "np" namespace, 
		eg. np.mean(X)
		- Similarly for plt.show() for 2D plots and pyplot.show() for 3D plots.

	- mlccLab3.ipynb: This is a jupyter notebook with instructions for the user 
	to follow.

	- lab3Test.ipynb: This is a jupyter notebook with ready made script to run 
	and TEST the code. 

--------------------------------------------------------------------------------
